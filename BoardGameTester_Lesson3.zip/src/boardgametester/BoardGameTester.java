/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boardgametester;
import games.board.*;
/**
 *
 * @author Francis Cuccio
 */
public class BoardGameTester {
    public static void main(String[] args) {
       // 3x3 board for Tic Tac Toe
       Board tttgameboard = new Board (3,3);
 
       // 6x7 board for Connect Four
       Board cfgameboard = new Board (6,7);
 
       // 5x8 board for Mastermind; blue mark
       Board mmgameboard = new Board (5,8);    
 
 
       System.out.println (" Tic Tac Toe ");
       tttgameboard.setCell(Mark.NOUGHT,1,1);
       System.out.println(tttgameboard.toString());
 
       System.out.println(" Connect Four ");
       cfgameboard.setCell(Mark.RED,4,3);
       System.out.println(cfgameboard.toString());
 
       System.out.println (" Mastermind ");
       mmgameboard.setCell(Mark.MAGENTA,3,6);
       System.out.println(mmgameboard.toString());
    }
}
