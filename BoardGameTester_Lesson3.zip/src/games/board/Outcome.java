/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package games.board;

/**
 *
 * @author Francis Cuccio
 */
public enum Outcome {PLAYER1_WIN, PLAYER2_WIN, CONTINUE, TIE}
